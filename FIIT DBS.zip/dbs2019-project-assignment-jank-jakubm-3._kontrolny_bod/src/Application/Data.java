package Application;

//Container class pre dolezite udaje ktore potrebuje program na svoj chod napr prepinanie

import javafx.stage.Stage;

public class Data {
    public static String logintype;
    public static String meno;
    public static String heslo;
    public static int id;
    public static Stage stage;

}
